"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/orders";
exports.ids = ["pages/api/orders"];
exports.modules = {

/***/ "serverless-mysql":
/*!***********************************!*\
  !*** external "serverless-mysql" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ "(api)/./helper/executeQuery.js":
/*!********************************!*\
  !*** ./helper/executeQuery.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ excuteQuery)\n/* harmony export */ });\n/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/db */ \"(api)/./utils/db.js\");\n\nasync function excuteQuery({\n  query,\n  values\n}) {\n  const results = await _utils_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"].query(query, values);\n  await _utils_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"].end();\n  return results;\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9oZWxwZXIvZXhlY3V0ZVF1ZXJ5LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7QUFFZSxlQUFlQyxXQUFmLENBQTJCO0FBQUVDLEVBQUFBLEtBQUY7QUFBU0MsRUFBQUE7QUFBVCxDQUEzQixFQUE4QztBQUM1RCxRQUFNQyxPQUFPLEdBQUcsTUFBTUosdURBQUEsQ0FBU0UsS0FBVCxFQUFnQkMsTUFBaEIsQ0FBdEI7QUFDQSxRQUFNSCxxREFBQSxFQUFOO0FBQ0EsU0FBT0ksT0FBUDtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL2hlbHBlci9leGVjdXRlUXVlcnkuanM/Mzk3YiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGIgZnJvbSAnLi4vdXRpbHMvZGInO1xuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBleGN1dGVRdWVyeSh7IHF1ZXJ5LCB2YWx1ZXMgfSkge1xuXHRjb25zdCByZXN1bHRzID0gYXdhaXQgZGIucXVlcnkocXVlcnksIHZhbHVlcyk7XG5cdGF3YWl0IGRiLmVuZCgpO1xuXHRyZXR1cm4gcmVzdWx0cztcbn1cbiJdLCJuYW1lcyI6WyJkYiIsImV4Y3V0ZVF1ZXJ5IiwicXVlcnkiLCJ2YWx1ZXMiLCJyZXN1bHRzIiwiZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./helper/executeQuery.js\n");

/***/ }),

/***/ "(api)/./helper/validateInt.js":
/*!*******************************!*\
  !*** ./helper/validateInt.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ validateInt)\n/* harmony export */ });\nasync function validateInt(req, res, value, name) {\n  const valueInt = parseInt(value);\n\n  if (isNaN(valueInt)) {\n    res.status(400).json({\n      error: {\n        message: `Invalid ${name}.`\n      }\n    }).end();\n    return false;\n  }\n\n  return true;\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9oZWxwZXIvdmFsaWRhdGVJbnQuanMuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUFlLGVBQWVBLFdBQWYsQ0FBMkJDLEdBQTNCLEVBQWdDQyxHQUFoQyxFQUFxQ0MsS0FBckMsRUFBNENDLElBQTVDLEVBQWtEO0FBQ2hFLFFBQU1DLFFBQVEsR0FBR0MsUUFBUSxDQUFDSCxLQUFELENBQXpCOztBQUNBLE1BQUlJLEtBQUssQ0FBQ0YsUUFBRCxDQUFULEVBQXFCO0FBQ3BCSCxJQUFBQSxHQUFHLENBQ0RNLE1BREYsQ0FDUyxHQURULEVBRUVDLElBRkYsQ0FFTztBQUFFQyxNQUFBQSxLQUFLLEVBQUU7QUFBRUMsUUFBQUEsT0FBTyxFQUFHLFdBQVVQLElBQUs7QUFBM0I7QUFBVCxLQUZQLEVBR0VRLEdBSEY7QUFJQSxXQUFPLEtBQVA7QUFDQTs7QUFDRCxTQUFPLElBQVA7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3BkYTYvLi9oZWxwZXIvdmFsaWRhdGVJbnQuanM/NDAxOCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiB2YWxpZGF0ZUludChyZXEsIHJlcywgdmFsdWUsIG5hbWUpIHtcblx0Y29uc3QgdmFsdWVJbnQgPSBwYXJzZUludCh2YWx1ZSk7XG5cdGlmIChpc05hTih2YWx1ZUludCkpIHtcblx0XHRyZXNcblx0XHRcdC5zdGF0dXMoNDAwKVxuXHRcdFx0Lmpzb24oeyBlcnJvcjogeyBtZXNzYWdlOiBgSW52YWxpZCAke25hbWV9LmAgfSB9KVxuXHRcdFx0LmVuZCgpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gdHJ1ZTtcbn1cbiJdLCJuYW1lcyI6WyJ2YWxpZGF0ZUludCIsInJlcSIsInJlcyIsInZhbHVlIiwibmFtZSIsInZhbHVlSW50IiwicGFyc2VJbnQiLCJpc05hTiIsInN0YXR1cyIsImpzb24iLCJlcnJvciIsIm1lc3NhZ2UiLCJlbmQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./helper/validateInt.js\n");

/***/ }),

/***/ "(api)/./pages/api/orders.js":
/*!*****************************!*\
  !*** ./pages/api/orders.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _helper_executeQuery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helper/executeQuery */ \"(api)/./helper/executeQuery.js\");\n/* harmony import */ var _helper_validateInt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../helper/validateInt */ \"(api)/./helper/validateInt.js\");\n/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils/db */ \"(api)/./utils/db.js\");\n\n\n\nconst CustomersTable = 'Customers';\nasync function handler(req, res) {\n  // Only allow GET requests\n  if (req.method != 'GET') {\n    res.status(405).end();\n    return;\n  }\n\n  try {\n    const name = req.query.name || '';\n    const limit = req.query.limit || 10;\n\n    if (!(0,_helper_validateInt__WEBPACK_IMPORTED_MODULE_1__[\"default\"])(req, res, limit, 'limit')) {\n      return;\n    }\n\n    const results = await (0,_helper_executeQuery__WEBPACK_IMPORTED_MODULE_0__[\"default\"])({\n      query: `\n\t\t\tSELECT c.id as customer_id, c.name, c.email, c.phone, o.id as order_id,\n\t\t\t\to.date, o.store_id\n\t\t\tFROM Orders o\n\t\t\tINNER JOIN Customers c on o.customer_id = c.id\n\t\t\tWHERE c.name LIKE ?\n\t\t\tORDER BY o.date DESC\n\t\t\tLIMIT ${limit};\n\t\t\t`,\n      values: [`%${name}%`]\n    });\n    res.status(200).json({\n      results,\n      meta: {\n        count: results.length\n      }\n    });\n  } catch (err) {\n    res.status(500).json({\n      error: err\n    });\n  }\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvb3JkZXJzLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFFQSxNQUFNRyxjQUFjLEdBQUcsV0FBdkI7QUFDZSxlQUFlQyxPQUFmLENBQXVCQyxHQUF2QixFQUE0QkMsR0FBNUIsRUFBaUM7QUFDL0M7QUFDQSxNQUFJRCxHQUFHLENBQUNFLE1BQUosSUFBYyxLQUFsQixFQUF5QjtBQUN4QkQsSUFBQUEsR0FBRyxDQUFDRSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsR0FBaEI7QUFDQTtBQUNBOztBQUVELE1BQUk7QUFDSCxVQUFNQyxJQUFJLEdBQUdMLEdBQUcsQ0FBQ00sS0FBSixDQUFVRCxJQUFWLElBQWtCLEVBQS9CO0FBRUEsVUFBTUUsS0FBSyxHQUFHUCxHQUFHLENBQUNNLEtBQUosQ0FBVUMsS0FBVixJQUFtQixFQUFqQzs7QUFDQSxRQUFJLENBQUNYLCtEQUFXLENBQUNJLEdBQUQsRUFBTUMsR0FBTixFQUFXTSxLQUFYLEVBQWtCLE9BQWxCLENBQWhCLEVBQTRDO0FBQzNDO0FBQ0E7O0FBRUQsVUFBTUMsT0FBTyxHQUFHLE1BQU1iLGdFQUFTLENBQUM7QUFDL0JXLE1BQUFBLEtBQUssRUFBRztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVdDLEtBQU07QUFDakIsSUFUa0M7QUFVL0JFLE1BQUFBLE1BQU0sRUFBRSxDQUFFLElBQUdKLElBQUssR0FBVjtBQVZ1QixLQUFELENBQS9CO0FBYUFKLElBQUFBLEdBQUcsQ0FBQ0UsTUFBSixDQUFXLEdBQVgsRUFBZ0JPLElBQWhCLENBQXFCO0FBQUVGLE1BQUFBLE9BQUY7QUFBV0csTUFBQUEsSUFBSSxFQUFFO0FBQUVDLFFBQUFBLEtBQUssRUFBRUosT0FBTyxDQUFDSztBQUFqQjtBQUFqQixLQUFyQjtBQUNBLEdBdEJELENBc0JFLE9BQU9DLEdBQVAsRUFBWTtBQUNiYixJQUFBQSxHQUFHLENBQUNFLE1BQUosQ0FBVyxHQUFYLEVBQWdCTyxJQUFoQixDQUFxQjtBQUFFSyxNQUFBQSxLQUFLLEVBQUVEO0FBQVQsS0FBckI7QUFDQTtBQUNEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL3BhZ2VzL2FwaS9vcmRlcnMuanM/MWE4OSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZXhlY1F1ZXJ5IGZyb20gJy4uLy4uL2hlbHBlci9leGVjdXRlUXVlcnknO1xuaW1wb3J0IHZhbGlkYXRlSW50IGZyb20gJy4uLy4uL2hlbHBlci92YWxpZGF0ZUludCc7XG5pbXBvcnQgZGIgZnJvbSAnLi4vLi4vdXRpbHMvZGInO1xuXG5jb25zdCBDdXN0b21lcnNUYWJsZSA9ICdDdXN0b21lcnMnO1xuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihyZXEsIHJlcykge1xuXHQvLyBPbmx5IGFsbG93IEdFVCByZXF1ZXN0c1xuXHRpZiAocmVxLm1ldGhvZCAhPSAnR0VUJykge1xuXHRcdHJlcy5zdGF0dXMoNDA1KS5lbmQoKTtcblx0XHRyZXR1cm47XG5cdH1cblxuXHR0cnkge1xuXHRcdGNvbnN0IG5hbWUgPSByZXEucXVlcnkubmFtZSB8fCAnJztcblxuXHRcdGNvbnN0IGxpbWl0ID0gcmVxLnF1ZXJ5LmxpbWl0IHx8IDEwO1xuXHRcdGlmICghdmFsaWRhdGVJbnQocmVxLCByZXMsIGxpbWl0LCAnbGltaXQnKSkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblxuXHRcdGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBleGVjUXVlcnkoe1xuXHRcdFx0cXVlcnk6IGBcblx0XHRcdFNFTEVDVCBjLmlkIGFzIGN1c3RvbWVyX2lkLCBjLm5hbWUsIGMuZW1haWwsIGMucGhvbmUsIG8uaWQgYXMgb3JkZXJfaWQsXG5cdFx0XHRcdG8uZGF0ZSwgby5zdG9yZV9pZFxuXHRcdFx0RlJPTSBPcmRlcnMgb1xuXHRcdFx0SU5ORVIgSk9JTiBDdXN0b21lcnMgYyBvbiBvLmN1c3RvbWVyX2lkID0gYy5pZFxuXHRcdFx0V0hFUkUgYy5uYW1lIExJS0UgP1xuXHRcdFx0T1JERVIgQlkgby5kYXRlIERFU0Ncblx0XHRcdExJTUlUICR7bGltaXR9O1xuXHRcdFx0YCxcblx0XHRcdHZhbHVlczogW2AlJHtuYW1lfSVgXSxcblx0XHR9KTtcblxuXHRcdHJlcy5zdGF0dXMoMjAwKS5qc29uKHsgcmVzdWx0cywgbWV0YTogeyBjb3VudDogcmVzdWx0cy5sZW5ndGggfSB9KTtcblx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0cmVzLnN0YXR1cyg1MDApLmpzb24oeyBlcnJvcjogZXJyIH0pO1xuXHR9XG59XG4iXSwibmFtZXMiOlsiZXhlY1F1ZXJ5IiwidmFsaWRhdGVJbnQiLCJkYiIsIkN1c3RvbWVyc1RhYmxlIiwiaGFuZGxlciIsInJlcSIsInJlcyIsIm1ldGhvZCIsInN0YXR1cyIsImVuZCIsIm5hbWUiLCJxdWVyeSIsImxpbWl0IiwicmVzdWx0cyIsInZhbHVlcyIsImpzb24iLCJtZXRhIiwiY291bnQiLCJsZW5ndGgiLCJlcnIiLCJlcnJvciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/orders.js\n");

/***/ }),

/***/ "(api)/./utils/db.js":
/*!*********************!*\
  !*** ./utils/db.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! serverless-mysql */ \"serverless-mysql\");\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);\n\nconst db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({\n  config: {\n    host: process.env.MYSQL_HOST,\n    port: process.env.MYSQL_PORT,\n    database: process.env.MYSQL_DATABASE,\n    user: process.env.MYSQL_USER,\n    password: process.env.MYSQL_PASSWORD // debug: true,\n\n  }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9kYi5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUVBLE1BQU1DLEVBQUUsR0FBR0QsdURBQUssQ0FBQztBQUNoQkUsRUFBQUEsTUFBTSxFQUFFO0FBQ1BDLElBQUFBLElBQUksRUFBRUMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLFVBRFg7QUFFUEMsSUFBQUEsSUFBSSxFQUFFSCxPQUFPLENBQUNDLEdBQVIsQ0FBWUcsVUFGWDtBQUdQQyxJQUFBQSxRQUFRLEVBQUVMLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSyxjQUhmO0FBSVBDLElBQUFBLElBQUksRUFBRVAsT0FBTyxDQUFDQyxHQUFSLENBQVlPLFVBSlg7QUFLUEMsSUFBQUEsUUFBUSxFQUFFVCxPQUFPLENBQUNDLEdBQVIsQ0FBWVMsY0FMZixDQU1QOztBQU5PO0FBRFEsQ0FBRCxDQUFoQjtBQVdBLGlFQUFlYixFQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL3V0aWxzL2RiLmpzPzdjYjIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG15c3FsIGZyb20gJ3NlcnZlcmxlc3MtbXlzcWwnO1xuXG5jb25zdCBkYiA9IG15c3FsKHtcblx0Y29uZmlnOiB7XG5cdFx0aG9zdDogcHJvY2Vzcy5lbnYuTVlTUUxfSE9TVCxcblx0XHRwb3J0OiBwcm9jZXNzLmVudi5NWVNRTF9QT1JULFxuXHRcdGRhdGFiYXNlOiBwcm9jZXNzLmVudi5NWVNRTF9EQVRBQkFTRSxcblx0XHR1c2VyOiBwcm9jZXNzLmVudi5NWVNRTF9VU0VSLFxuXHRcdHBhc3N3b3JkOiBwcm9jZXNzLmVudi5NWVNRTF9QQVNTV09SRCxcblx0XHQvLyBkZWJ1ZzogdHJ1ZSxcblx0fSxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBkYjtcbiJdLCJuYW1lcyI6WyJteXNxbCIsImRiIiwiY29uZmlnIiwiaG9zdCIsInByb2Nlc3MiLCJlbnYiLCJNWVNRTF9IT1NUIiwicG9ydCIsIk1ZU1FMX1BPUlQiLCJkYXRhYmFzZSIsIk1ZU1FMX0RBVEFCQVNFIiwidXNlciIsIk1ZU1FMX1VTRVIiLCJwYXNzd29yZCIsIk1ZU1FMX1BBU1NXT1JEIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./utils/db.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/orders.js"));
module.exports = __webpack_exports__;

})();