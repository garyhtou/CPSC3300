"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/tables";
exports.ids = ["pages/api/tables"];
exports.modules = {

/***/ "serverless-mysql":
/*!***********************************!*\
  !*** external "serverless-mysql" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ "(api)/./helper/executeQuery.js":
/*!********************************!*\
  !*** ./helper/executeQuery.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ excuteQuery)\n/* harmony export */ });\n/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/db */ \"(api)/./utils/db.js\");\n\nasync function excuteQuery({\n  query,\n  values\n}) {\n  const results = await _utils_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"].query(query, values);\n  await _utils_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"].end();\n  return results;\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9oZWxwZXIvZXhlY3V0ZVF1ZXJ5LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7QUFFZSxlQUFlQyxXQUFmLENBQTJCO0FBQUVDLEVBQUFBLEtBQUY7QUFBU0MsRUFBQUE7QUFBVCxDQUEzQixFQUE4QztBQUM1RCxRQUFNQyxPQUFPLEdBQUcsTUFBTUosdURBQUEsQ0FBU0UsS0FBVCxFQUFnQkMsTUFBaEIsQ0FBdEI7QUFDQSxRQUFNSCxxREFBQSxFQUFOO0FBQ0EsU0FBT0ksT0FBUDtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL2hlbHBlci9leGVjdXRlUXVlcnkuanM/Mzk3YiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGIgZnJvbSAnLi4vdXRpbHMvZGInO1xuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBleGN1dGVRdWVyeSh7IHF1ZXJ5LCB2YWx1ZXMgfSkge1xuXHRjb25zdCByZXN1bHRzID0gYXdhaXQgZGIucXVlcnkocXVlcnksIHZhbHVlcyk7XG5cdGF3YWl0IGRiLmVuZCgpO1xuXHRyZXR1cm4gcmVzdWx0cztcbn1cbiJdLCJuYW1lcyI6WyJkYiIsImV4Y3V0ZVF1ZXJ5IiwicXVlcnkiLCJ2YWx1ZXMiLCJyZXN1bHRzIiwiZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./helper/executeQuery.js\n");

/***/ }),

/***/ "(api)/./pages/api/tables.js":
/*!*****************************!*\
  !*** ./pages/api/tables.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _helper_executeQuery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helper/executeQuery */ \"(api)/./helper/executeQuery.js\");\n\nconst tables = ['Customers', 'Items', 'Stores', 'Orders', 'OrderItems'];\nasync function handler(req, res) {\n  // Only allow GET requests\n  if (req.method != 'GET') {\n    res.status(405).end();\n    return;\n  }\n\n  try {\n    const results = Object.assign(...(await Promise.all(tables.map(async table => {\n      var result = {};\n      result[table] = await (0,_helper_executeQuery__WEBPACK_IMPORTED_MODULE_0__[\"default\"])({\n        query: `DESCRIBE ${table};`\n      });\n      return result;\n    }))));\n    res.status(200).json({\n      results,\n      meta: {\n        count: results.length\n      }\n    });\n  } catch (err) {\n    res.status(500).json({\n      error: err\n    });\n  }\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvdGFibGVzLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7QUFFQSxNQUFNQyxNQUFNLEdBQUcsQ0FBQyxXQUFELEVBQWMsT0FBZCxFQUF1QixRQUF2QixFQUFpQyxRQUFqQyxFQUEyQyxZQUEzQyxDQUFmO0FBQ2UsZUFBZUMsT0FBZixDQUF1QkMsR0FBdkIsRUFBNEJDLEdBQTVCLEVBQWlDO0FBQy9DO0FBQ0EsTUFBSUQsR0FBRyxDQUFDRSxNQUFKLElBQWMsS0FBbEIsRUFBeUI7QUFDeEJELElBQUFBLEdBQUcsQ0FBQ0UsTUFBSixDQUFXLEdBQVgsRUFBZ0JDLEdBQWhCO0FBQ0E7QUFDQTs7QUFFRCxNQUFJO0FBQ0gsVUFBTUMsT0FBTyxHQUFHQyxNQUFNLENBQUNDLE1BQVAsQ0FDZixJQUFJLE1BQU1DLE9BQU8sQ0FBQ0MsR0FBUixDQUNUWCxNQUFNLENBQUNZLEdBQVAsQ0FBVyxNQUFPQyxLQUFQLElBQWlCO0FBQzNCLFVBQUlDLE1BQU0sR0FBRyxFQUFiO0FBQ0FBLE1BQUFBLE1BQU0sQ0FBQ0QsS0FBRCxDQUFOLEdBQWdCLE1BQU1kLGdFQUFTLENBQUM7QUFBRWdCLFFBQUFBLEtBQUssRUFBRyxZQUFXRixLQUFNO0FBQTNCLE9BQUQsQ0FBL0I7QUFDQSxhQUFPQyxNQUFQO0FBQ0EsS0FKRCxDQURTLENBQVYsQ0FEZSxDQUFoQjtBQVVBWCxJQUFBQSxHQUFHLENBQUNFLE1BQUosQ0FBVyxHQUFYLEVBQWdCVyxJQUFoQixDQUFxQjtBQUFFVCxNQUFBQSxPQUFGO0FBQVdVLE1BQUFBLElBQUksRUFBRTtBQUFFQyxRQUFBQSxLQUFLLEVBQUVYLE9BQU8sQ0FBQ1k7QUFBakI7QUFBakIsS0FBckI7QUFDQSxHQVpELENBWUUsT0FBT0MsR0FBUCxFQUFZO0FBQ2JqQixJQUFBQSxHQUFHLENBQUNFLE1BQUosQ0FBVyxHQUFYLEVBQWdCVyxJQUFoQixDQUFxQjtBQUFFSyxNQUFBQSxLQUFLLEVBQUVEO0FBQVQsS0FBckI7QUFDQTtBQUNEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL3BhZ2VzL2FwaS90YWJsZXMuanM/YWY1OCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZXhlY1F1ZXJ5IGZyb20gJy4uLy4uL2hlbHBlci9leGVjdXRlUXVlcnknO1xuXG5jb25zdCB0YWJsZXMgPSBbJ0N1c3RvbWVycycsICdJdGVtcycsICdTdG9yZXMnLCAnT3JkZXJzJywgJ09yZGVySXRlbXMnXTtcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcblx0Ly8gT25seSBhbGxvdyBHRVQgcmVxdWVzdHNcblx0aWYgKHJlcS5tZXRob2QgIT0gJ0dFVCcpIHtcblx0XHRyZXMuc3RhdHVzKDQwNSkuZW5kKCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cblx0dHJ5IHtcblx0XHRjb25zdCByZXN1bHRzID0gT2JqZWN0LmFzc2lnbihcblx0XHRcdC4uLihhd2FpdCBQcm9taXNlLmFsbChcblx0XHRcdFx0dGFibGVzLm1hcChhc3luYyAodGFibGUpID0+IHtcblx0XHRcdFx0XHR2YXIgcmVzdWx0ID0ge307XG5cdFx0XHRcdFx0cmVzdWx0W3RhYmxlXSA9IGF3YWl0IGV4ZWNRdWVyeSh7IHF1ZXJ5OiBgREVTQ1JJQkUgJHt0YWJsZX07YCB9KTtcblx0XHRcdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdFx0XHR9KVxuXHRcdFx0KSlcblx0XHQpO1xuXG5cdFx0cmVzLnN0YXR1cygyMDApLmpzb24oeyByZXN1bHRzLCBtZXRhOiB7IGNvdW50OiByZXN1bHRzLmxlbmd0aCB9IH0pO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRyZXMuc3RhdHVzKDUwMCkuanNvbih7IGVycm9yOiBlcnIgfSk7XG5cdH1cbn1cbiJdLCJuYW1lcyI6WyJleGVjUXVlcnkiLCJ0YWJsZXMiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwibWV0aG9kIiwic3RhdHVzIiwiZW5kIiwicmVzdWx0cyIsIk9iamVjdCIsImFzc2lnbiIsIlByb21pc2UiLCJhbGwiLCJtYXAiLCJ0YWJsZSIsInJlc3VsdCIsInF1ZXJ5IiwianNvbiIsIm1ldGEiLCJjb3VudCIsImxlbmd0aCIsImVyciIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/tables.js\n");

/***/ }),

/***/ "(api)/./utils/db.js":
/*!*********************!*\
  !*** ./utils/db.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! serverless-mysql */ \"serverless-mysql\");\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);\n\nconst db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({\n  config: {\n    host: process.env.MYSQL_HOST,\n    port: process.env.MYSQL_PORT,\n    database: process.env.MYSQL_DATABASE,\n    user: process.env.MYSQL_USER,\n    password: process.env.MYSQL_PASSWORD // debug: true,\n\n  }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9kYi5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUVBLE1BQU1DLEVBQUUsR0FBR0QsdURBQUssQ0FBQztBQUNoQkUsRUFBQUEsTUFBTSxFQUFFO0FBQ1BDLElBQUFBLElBQUksRUFBRUMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLFVBRFg7QUFFUEMsSUFBQUEsSUFBSSxFQUFFSCxPQUFPLENBQUNDLEdBQVIsQ0FBWUcsVUFGWDtBQUdQQyxJQUFBQSxRQUFRLEVBQUVMLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSyxjQUhmO0FBSVBDLElBQUFBLElBQUksRUFBRVAsT0FBTyxDQUFDQyxHQUFSLENBQVlPLFVBSlg7QUFLUEMsSUFBQUEsUUFBUSxFQUFFVCxPQUFPLENBQUNDLEdBQVIsQ0FBWVMsY0FMZixDQU1QOztBQU5PO0FBRFEsQ0FBRCxDQUFoQjtBQVdBLGlFQUFlYixFQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL3V0aWxzL2RiLmpzPzdjYjIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG15c3FsIGZyb20gJ3NlcnZlcmxlc3MtbXlzcWwnO1xuXG5jb25zdCBkYiA9IG15c3FsKHtcblx0Y29uZmlnOiB7XG5cdFx0aG9zdDogcHJvY2Vzcy5lbnYuTVlTUUxfSE9TVCxcblx0XHRwb3J0OiBwcm9jZXNzLmVudi5NWVNRTF9QT1JULFxuXHRcdGRhdGFiYXNlOiBwcm9jZXNzLmVudi5NWVNRTF9EQVRBQkFTRSxcblx0XHR1c2VyOiBwcm9jZXNzLmVudi5NWVNRTF9VU0VSLFxuXHRcdHBhc3N3b3JkOiBwcm9jZXNzLmVudi5NWVNRTF9QQVNTV09SRCxcblx0XHQvLyBkZWJ1ZzogdHJ1ZSxcblx0fSxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBkYjtcbiJdLCJuYW1lcyI6WyJteXNxbCIsImRiIiwiY29uZmlnIiwiaG9zdCIsInByb2Nlc3MiLCJlbnYiLCJNWVNRTF9IT1NUIiwicG9ydCIsIk1ZU1FMX1BPUlQiLCJkYXRhYmFzZSIsIk1ZU1FMX0RBVEFCQVNFIiwidXNlciIsIk1ZU1FMX1VTRVIiLCJwYXNzd29yZCIsIk1ZU1FMX1BBU1NXT1JEIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./utils/db.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/tables.js"));
module.exports = __webpack_exports__;

})();