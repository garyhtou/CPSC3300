"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/calories";
exports.ids = ["pages/api/calories"];
exports.modules = {

/***/ "serverless-mysql":
/*!***********************************!*\
  !*** external "serverless-mysql" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ "(api)/./helper/executeQuery.js":
/*!********************************!*\
  !*** ./helper/executeQuery.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ excuteQuery)\n/* harmony export */ });\n/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/db */ \"(api)/./utils/db.js\");\n\nasync function excuteQuery({\n  query,\n  values\n}) {\n  const results = await _utils_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"].query(query, values);\n  await _utils_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"].end();\n  return results;\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9oZWxwZXIvZXhlY3V0ZVF1ZXJ5LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7QUFFZSxlQUFlQyxXQUFmLENBQTJCO0FBQUVDLEVBQUFBLEtBQUY7QUFBU0MsRUFBQUE7QUFBVCxDQUEzQixFQUE4QztBQUM1RCxRQUFNQyxPQUFPLEdBQUcsTUFBTUosdURBQUEsQ0FBU0UsS0FBVCxFQUFnQkMsTUFBaEIsQ0FBdEI7QUFDQSxRQUFNSCxxREFBQSxFQUFOO0FBQ0EsU0FBT0ksT0FBUDtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL2hlbHBlci9leGVjdXRlUXVlcnkuanM/Mzk3YiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZGIgZnJvbSAnLi4vdXRpbHMvZGInO1xuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBleGN1dGVRdWVyeSh7IHF1ZXJ5LCB2YWx1ZXMgfSkge1xuXHRjb25zdCByZXN1bHRzID0gYXdhaXQgZGIucXVlcnkocXVlcnksIHZhbHVlcyk7XG5cdGF3YWl0IGRiLmVuZCgpO1xuXHRyZXR1cm4gcmVzdWx0cztcbn1cbiJdLCJuYW1lcyI6WyJkYiIsImV4Y3V0ZVF1ZXJ5IiwicXVlcnkiLCJ2YWx1ZXMiLCJyZXN1bHRzIiwiZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./helper/executeQuery.js\n");

/***/ }),

/***/ "(api)/./helper/validateInt.js":
/*!*******************************!*\
  !*** ./helper/validateInt.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ validateInt)\n/* harmony export */ });\nasync function validateInt(req, res, value, name) {\n  const valueInt = parseInt(value);\n\n  if (isNaN(valueInt)) {\n    res.status(400).json({\n      error: {\n        message: `Invalid ${name}.`\n      }\n    }).end();\n    return false;\n  }\n\n  return true;\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9oZWxwZXIvdmFsaWRhdGVJbnQuanMuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUFlLGVBQWVBLFdBQWYsQ0FBMkJDLEdBQTNCLEVBQWdDQyxHQUFoQyxFQUFxQ0MsS0FBckMsRUFBNENDLElBQTVDLEVBQWtEO0FBQ2hFLFFBQU1DLFFBQVEsR0FBR0MsUUFBUSxDQUFDSCxLQUFELENBQXpCOztBQUNBLE1BQUlJLEtBQUssQ0FBQ0YsUUFBRCxDQUFULEVBQXFCO0FBQ3BCSCxJQUFBQSxHQUFHLENBQ0RNLE1BREYsQ0FDUyxHQURULEVBRUVDLElBRkYsQ0FFTztBQUFFQyxNQUFBQSxLQUFLLEVBQUU7QUFBRUMsUUFBQUEsT0FBTyxFQUFHLFdBQVVQLElBQUs7QUFBM0I7QUFBVCxLQUZQLEVBR0VRLEdBSEY7QUFJQSxXQUFPLEtBQVA7QUFDQTs7QUFDRCxTQUFPLElBQVA7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3BkYTYvLi9oZWxwZXIvdmFsaWRhdGVJbnQuanM/NDAxOCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiB2YWxpZGF0ZUludChyZXEsIHJlcywgdmFsdWUsIG5hbWUpIHtcblx0Y29uc3QgdmFsdWVJbnQgPSBwYXJzZUludCh2YWx1ZSk7XG5cdGlmIChpc05hTih2YWx1ZUludCkpIHtcblx0XHRyZXNcblx0XHRcdC5zdGF0dXMoNDAwKVxuXHRcdFx0Lmpzb24oeyBlcnJvcjogeyBtZXNzYWdlOiBgSW52YWxpZCAke25hbWV9LmAgfSB9KVxuXHRcdFx0LmVuZCgpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gdHJ1ZTtcbn1cbiJdLCJuYW1lcyI6WyJ2YWxpZGF0ZUludCIsInJlcSIsInJlcyIsInZhbHVlIiwibmFtZSIsInZhbHVlSW50IiwicGFyc2VJbnQiLCJpc05hTiIsInN0YXR1cyIsImpzb24iLCJlcnJvciIsIm1lc3NhZ2UiLCJlbmQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./helper/validateInt.js\n");

/***/ }),

/***/ "(api)/./pages/api/calories.js":
/*!*******************************!*\
  !*** ./pages/api/calories.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _helper_executeQuery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../helper/executeQuery */ \"(api)/./helper/executeQuery.js\");\n/* harmony import */ var _helper_validateInt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../helper/validateInt */ \"(api)/./helper/validateInt.js\");\n\n\nasync function handler(req, res) {\n  // Only allow GET requests\n  if (req.method != 'GET') {\n    res.status(405).end();\n    return;\n  }\n\n  try {\n    const groupSize = req.query.interval || 100;\n\n    if (!(0,_helper_validateInt__WEBPACK_IMPORTED_MODULE_1__[\"default\"])(req, res, groupSize, 'group size')) {\n      return;\n    }\n\n    const limit = req.query.limit || 10;\n\n    if (!(0,_helper_validateInt__WEBPACK_IMPORTED_MODULE_1__[\"default\"])(req, res, limit, 'limit')) {\n      return;\n    }\n\n    const results = await (0,_helper_executeQuery__WEBPACK_IMPORTED_MODULE_0__[\"default\"])({\n      query: `\n\t\t\tSELECT calories, AVG(price_cents) as average_price_cents\n\t\t\tFROM (\n\t\t\t\tSELECT ROUND(calories/${groupSize}) * ${groupSize} as calories, price_cents\n\t\t\t\tFROM Items\n\t\t\t) r\n\t\t\tGROUP BY calories\n\t\t\tORDER BY calories ASC\n\t\t\tLIMIT ${limit};\n\t\t\t`\n    }); // Convert price cents to dolar amount\n\n    results.forEach(row => {\n      if (row.calories == null) {\n        row.calories = 'No Calorie Data';\n      }\n\n      row.average_price = '$' + Math.round(row.average_price_cents) / 100;\n      delete row['average_price_cents'];\n      return row;\n    });\n    res.status(200).json({\n      results,\n      meta: {\n        count: results.length\n      }\n    });\n  } catch (err) {\n    res.status(500).json({\n      error: err\n    });\n  }\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvY2Fsb3JpZXMuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUVlLGVBQWVFLE9BQWYsQ0FBdUJDLEdBQXZCLEVBQTRCQyxHQUE1QixFQUFpQztBQUMvQztBQUNBLE1BQUlELEdBQUcsQ0FBQ0UsTUFBSixJQUFjLEtBQWxCLEVBQXlCO0FBQ3hCRCxJQUFBQSxHQUFHLENBQUNFLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxHQUFoQjtBQUNBO0FBQ0E7O0FBRUQsTUFBSTtBQUNILFVBQU1DLFNBQVMsR0FBR0wsR0FBRyxDQUFDTSxLQUFKLENBQVVDLFFBQVYsSUFBc0IsR0FBeEM7O0FBQ0EsUUFBSSxDQUFDVCwrREFBVyxDQUFDRSxHQUFELEVBQU1DLEdBQU4sRUFBV0ksU0FBWCxFQUFzQixZQUF0QixDQUFoQixFQUFxRDtBQUNwRDtBQUNBOztBQUNELFVBQU1HLEtBQUssR0FBR1IsR0FBRyxDQUFDTSxLQUFKLENBQVVFLEtBQVYsSUFBbUIsRUFBakM7O0FBQ0EsUUFBSSxDQUFDViwrREFBVyxDQUFDRSxHQUFELEVBQU1DLEdBQU4sRUFBV08sS0FBWCxFQUFrQixPQUFsQixDQUFoQixFQUE0QztBQUMzQztBQUNBOztBQUVELFVBQU1DLE9BQU8sR0FBRyxNQUFNWixnRUFBUyxDQUFDO0FBQy9CUyxNQUFBQSxLQUFLLEVBQUc7QUFDWDtBQUNBO0FBQ0EsNEJBQTRCRCxTQUFVLE9BQU1BLFNBQVU7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXRyxLQUFNO0FBQ2pCO0FBVmtDLEtBQUQsQ0FBL0IsQ0FWRyxDQXVCSDs7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxPQUFSLENBQWlCQyxHQUFELElBQVM7QUFDeEIsVUFBSUEsR0FBRyxDQUFDQyxRQUFKLElBQWdCLElBQXBCLEVBQTBCO0FBQ3pCRCxRQUFBQSxHQUFHLENBQUNDLFFBQUosR0FBZSxpQkFBZjtBQUNBOztBQUNERCxNQUFBQSxHQUFHLENBQUNFLGFBQUosR0FBb0IsTUFBTUMsSUFBSSxDQUFDQyxLQUFMLENBQVdKLEdBQUcsQ0FBQ0ssbUJBQWYsSUFBc0MsR0FBaEU7QUFDQSxhQUFPTCxHQUFHLENBQUMscUJBQUQsQ0FBVjtBQUNBLGFBQU9BLEdBQVA7QUFDQSxLQVBEO0FBU0FWLElBQUFBLEdBQUcsQ0FBQ0UsTUFBSixDQUFXLEdBQVgsRUFBZ0JjLElBQWhCLENBQXFCO0FBQUVSLE1BQUFBLE9BQUY7QUFBV1MsTUFBQUEsSUFBSSxFQUFFO0FBQUVDLFFBQUFBLEtBQUssRUFBRVYsT0FBTyxDQUFDVztBQUFqQjtBQUFqQixLQUFyQjtBQUNBLEdBbENELENBa0NFLE9BQU9DLEdBQVAsRUFBWTtBQUNicEIsSUFBQUEsR0FBRyxDQUFDRSxNQUFKLENBQVcsR0FBWCxFQUFnQmMsSUFBaEIsQ0FBcUI7QUFBRUssTUFBQUEsS0FBSyxFQUFFRDtBQUFULEtBQXJCO0FBQ0E7QUFDRCIsInNvdXJjZXMiOlsid2VicGFjazovL3BkYTYvLi9wYWdlcy9hcGkvY2Fsb3JpZXMuanM/MDBlNCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZXhlY1F1ZXJ5IGZyb20gJy4uLy4uL2hlbHBlci9leGVjdXRlUXVlcnknO1xuaW1wb3J0IHZhbGlkYXRlSW50IGZyb20gJy4uLy4uL2hlbHBlci92YWxpZGF0ZUludCc7XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcblx0Ly8gT25seSBhbGxvdyBHRVQgcmVxdWVzdHNcblx0aWYgKHJlcS5tZXRob2QgIT0gJ0dFVCcpIHtcblx0XHRyZXMuc3RhdHVzKDQwNSkuZW5kKCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cblx0dHJ5IHtcblx0XHRjb25zdCBncm91cFNpemUgPSByZXEucXVlcnkuaW50ZXJ2YWwgfHwgMTAwO1xuXHRcdGlmICghdmFsaWRhdGVJbnQocmVxLCByZXMsIGdyb3VwU2l6ZSwgJ2dyb3VwIHNpemUnKSkge1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRjb25zdCBsaW1pdCA9IHJlcS5xdWVyeS5saW1pdCB8fCAxMDtcblx0XHRpZiAoIXZhbGlkYXRlSW50KHJlcSwgcmVzLCBsaW1pdCwgJ2xpbWl0JykpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cblx0XHRjb25zdCByZXN1bHRzID0gYXdhaXQgZXhlY1F1ZXJ5KHtcblx0XHRcdHF1ZXJ5OiBgXG5cdFx0XHRTRUxFQ1QgY2Fsb3JpZXMsIEFWRyhwcmljZV9jZW50cykgYXMgYXZlcmFnZV9wcmljZV9jZW50c1xuXHRcdFx0RlJPTSAoXG5cdFx0XHRcdFNFTEVDVCBST1VORChjYWxvcmllcy8ke2dyb3VwU2l6ZX0pICogJHtncm91cFNpemV9IGFzIGNhbG9yaWVzLCBwcmljZV9jZW50c1xuXHRcdFx0XHRGUk9NIEl0ZW1zXG5cdFx0XHQpIHJcblx0XHRcdEdST1VQIEJZIGNhbG9yaWVzXG5cdFx0XHRPUkRFUiBCWSBjYWxvcmllcyBBU0Ncblx0XHRcdExJTUlUICR7bGltaXR9O1xuXHRcdFx0YCxcblx0XHR9KTtcblxuXHRcdC8vIENvbnZlcnQgcHJpY2UgY2VudHMgdG8gZG9sYXIgYW1vdW50XG5cdFx0cmVzdWx0cy5mb3JFYWNoKChyb3cpID0+IHtcblx0XHRcdGlmIChyb3cuY2Fsb3JpZXMgPT0gbnVsbCkge1xuXHRcdFx0XHRyb3cuY2Fsb3JpZXMgPSAnTm8gQ2Fsb3JpZSBEYXRhJztcblx0XHRcdH1cblx0XHRcdHJvdy5hdmVyYWdlX3ByaWNlID0gJyQnICsgTWF0aC5yb3VuZChyb3cuYXZlcmFnZV9wcmljZV9jZW50cykgLyAxMDA7XG5cdFx0XHRkZWxldGUgcm93WydhdmVyYWdlX3ByaWNlX2NlbnRzJ107XG5cdFx0XHRyZXR1cm4gcm93O1xuXHRcdH0pO1xuXG5cdFx0cmVzLnN0YXR1cygyMDApLmpzb24oeyByZXN1bHRzLCBtZXRhOiB7IGNvdW50OiByZXN1bHRzLmxlbmd0aCB9IH0pO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRyZXMuc3RhdHVzKDUwMCkuanNvbih7IGVycm9yOiBlcnIgfSk7XG5cdH1cbn1cbiJdLCJuYW1lcyI6WyJleGVjUXVlcnkiLCJ2YWxpZGF0ZUludCIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJtZXRob2QiLCJzdGF0dXMiLCJlbmQiLCJncm91cFNpemUiLCJxdWVyeSIsImludGVydmFsIiwibGltaXQiLCJyZXN1bHRzIiwiZm9yRWFjaCIsInJvdyIsImNhbG9yaWVzIiwiYXZlcmFnZV9wcmljZSIsIk1hdGgiLCJyb3VuZCIsImF2ZXJhZ2VfcHJpY2VfY2VudHMiLCJqc29uIiwibWV0YSIsImNvdW50IiwibGVuZ3RoIiwiZXJyIiwiZXJyb3IiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/calories.js\n");

/***/ }),

/***/ "(api)/./utils/db.js":
/*!*********************!*\
  !*** ./utils/db.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! serverless-mysql */ \"serverless-mysql\");\n/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);\n\nconst db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({\n  config: {\n    host: process.env.MYSQL_HOST,\n    port: process.env.MYSQL_PORT,\n    database: process.env.MYSQL_DATABASE,\n    user: process.env.MYSQL_USER,\n    password: process.env.MYSQL_PASSWORD // debug: true,\n\n  }\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9kYi5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUVBLE1BQU1DLEVBQUUsR0FBR0QsdURBQUssQ0FBQztBQUNoQkUsRUFBQUEsTUFBTSxFQUFFO0FBQ1BDLElBQUFBLElBQUksRUFBRUMsT0FBTyxDQUFDQyxHQUFSLENBQVlDLFVBRFg7QUFFUEMsSUFBQUEsSUFBSSxFQUFFSCxPQUFPLENBQUNDLEdBQVIsQ0FBWUcsVUFGWDtBQUdQQyxJQUFBQSxRQUFRLEVBQUVMLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSyxjQUhmO0FBSVBDLElBQUFBLElBQUksRUFBRVAsT0FBTyxDQUFDQyxHQUFSLENBQVlPLFVBSlg7QUFLUEMsSUFBQUEsUUFBUSxFQUFFVCxPQUFPLENBQUNDLEdBQVIsQ0FBWVMsY0FMZixDQU1QOztBQU5PO0FBRFEsQ0FBRCxDQUFoQjtBQVdBLGlFQUFlYixFQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGRhNi8uL3V0aWxzL2RiLmpzPzdjYjIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG15c3FsIGZyb20gJ3NlcnZlcmxlc3MtbXlzcWwnO1xuXG5jb25zdCBkYiA9IG15c3FsKHtcblx0Y29uZmlnOiB7XG5cdFx0aG9zdDogcHJvY2Vzcy5lbnYuTVlTUUxfSE9TVCxcblx0XHRwb3J0OiBwcm9jZXNzLmVudi5NWVNRTF9QT1JULFxuXHRcdGRhdGFiYXNlOiBwcm9jZXNzLmVudi5NWVNRTF9EQVRBQkFTRSxcblx0XHR1c2VyOiBwcm9jZXNzLmVudi5NWVNRTF9VU0VSLFxuXHRcdHBhc3N3b3JkOiBwcm9jZXNzLmVudi5NWVNRTF9QQVNTV09SRCxcblx0XHQvLyBkZWJ1ZzogdHJ1ZSxcblx0fSxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBkYjtcbiJdLCJuYW1lcyI6WyJteXNxbCIsImRiIiwiY29uZmlnIiwiaG9zdCIsInByb2Nlc3MiLCJlbnYiLCJNWVNRTF9IT1NUIiwicG9ydCIsIk1ZU1FMX1BPUlQiLCJkYXRhYmFzZSIsIk1ZU1FMX0RBVEFCQVNFIiwidXNlciIsIk1ZU1FMX1VTRVIiLCJwYXNzd29yZCIsIk1ZU1FMX1BBU1NXT1JEIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./utils/db.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/calories.js"));
module.exports = __webpack_exports__;

})();